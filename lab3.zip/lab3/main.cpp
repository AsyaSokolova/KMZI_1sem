#include "Steg.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define ERROR 1

using namespace steg;

const char *readEntireFile(const char *filename);

int main(int argc, const char * argv[]) {
	if (argc < 2) {
	cout <<"Stegosaur \n";
	cout << "Options : \n";
	cout << "[messagefilename] [bitmapfilename] : encryption \n";
	cout << "[bitmapfilename] : decryption \n" ;
		return ERROR;
		
	} else if (argc == 2 ) {  //SEEK
		
		char *message = extractMessageFromBitmap(argv[1]);
		if (!message) {
			cout << "Error!\n";
			return ERROR;

		} else {
			cout << "Found a message!:\n";
			cout << message << '\n';
		}
	
	} else if (argc == 3) {  //HIDE
		
		const char *message = readEntireFile(argv[1]);
		if (!message) {
			cout << "Error!\n";
			return ERROR;
		}
		if (!hideMessageInBitmap(message, argv[2])) {
			cout << "Error!\n";
			return ERROR;
		} else {
			cout << "Message is encrypted!\n";
		}
		
	} else {
		cout << "Too many arguments! \n";
		return ERROR;
	}
	
    return SUCCESS;
}

const char *readEntireFile(const char *filename) {
	ifstream file;
	file.open(filename, ifstream::binary);
	
	if (file.fail()) {
		cout << "Could not find message file\n";
		return NULL;
	}
	
	file.seekg(0, file.end);
	int fileLength = (int) file.tellg();
	
	if (fileLength > USHRT_MAX) {
		cout << "Message too long! Message must at least be shorter than "
			 << USHRT_MAX << " bytes\n";
		return NULL;
	}
	
	file.seekg(0, file.beg);
	char *fileContents = (char *) malloc(fileLength + 1);
	file.read(fileContents, fileLength);
	
	return fileContents;
}
